..........................
      o          o
.ooo..o..o..ooo..o...oooo.
o   o o.o  o ..  o   .oo.
.ooo..o..o..ooo...oo.ooooo

BEST  QUALITY  SINCE  1998
http://www.oketz.com/fonts
FREE HEBREW FONT DOWNLOAD!
THE BEST  o-9  DAY  FONTz!
=-=-=-:This release:-=-=-=
       YOAV CURSIVE
      for Windows 95+
    Regular + X Version
=-=-=-=-=-=--=-=-=-=-=-=-=
A  cursive version for the
Yoav font.
=-=-=-=-=-=--=-=-=-=-=-=-=
Copyright � MeiR SaDaN (!)
