AEIOU
http://aeiou.ru/aeiou/
